import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../domain/models/project_model.dart';
import 'content_placeholder.dart';

/// Lead image / placeholder for gallery tiles and case-study headers.
/// When [heroTag] is set (e.g. [CaseStudyHeroTags.projectLeadImage] for Movement),
/// wraps the raster in a [Hero] flight shell ([Material] + clip).
class ProjectLeadMedia extends StatelessWidget {
  const ProjectLeadMedia({
    super.key,
    required this.project,
    required this.isArabic,
    this.tall = true,
    this.heroTag,
  });

  final ProjectModel project;
  final bool isArabic;
  final bool tall;

  /// If non-null, this widget participates in a hero transition.
  final String? heroTag;

  @override
  Widget build(BuildContext context) {
    final path = project.imageAsset;
    final placeholder = ContentPlaceholder(
      aspectRatio: tall ? 16 / 10 : 16 / 9,
      label: _placeholderCopy(project.id, isArabic),
      icon: Icons.dashboard_customize_outlined,
    );

    Widget core;
    if (path == null) {
      core = placeholder;
    } else {
      core = Image.asset(
        path,
        fit: BoxFit.cover,
        gaplessPlayback: true,
        filterQuality: FilterQuality.medium,
        errorBuilder: (context, error, stackTrace) => placeholder,
      );
    }

    core = ClipRRect(
      borderRadius: BorderRadius.circular(4),
      child: core,
    );

    if (heroTag != null) {
      core = Hero(
        tag: heroTag!,
        child: Material(
          color: AppColors.surfaceElevated,
          child: core,
        ),
      );
    }

    return core;
  }

  String _placeholderCopy(String id, bool ar) {
    switch (id) {
      case 'movement':
        return ar
            ? 'TODO: لقطة 16:10 لخريطة الأسطول + مؤشرات الأداء توضح التعقيد التشغيلي.'
            : 'TODO: 16:10 fleet map + KPI dashboard screenshot (proves operational depth).';
      case 'click':
        return ar
            ? 'TODO: لقطة تطبيق 9:16 لمسار الدفع/التتبع لرفع الثقة لدى العملاء.'
            : 'TODO: 9:16 mobile frame of checkout/live tracking (trust + conversion).';
      default:
        return ar
            ? 'TODO: لقطة منتج عالية الدقة للمشروع الجديد.'
            : 'TODO: crisp product screenshot for this case study.';
    }
  }
}
