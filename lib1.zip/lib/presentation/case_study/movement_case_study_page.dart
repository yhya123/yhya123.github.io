import 'package:flutter/material.dart';

import '../../core/locale/locale_scope.dart';
import '../../core/theme/app_colors.dart';
import '../../data/project_catalog.dart';
import '../../domain/models/project_model.dart';
import '../widgets/project_lead_media.dart';
import 'case_study_hero_tags.dart';
import 'case_study_layout.dart';

/// Deep-dive case study: Movement System / نظام الحركة.
class MovementCaseStudyPage extends StatelessWidget {
  const MovementCaseStudyPage({super.key});

  ProjectModel get _project =>
      kFeaturedProjects.firstWhere((p) => p.id == 'movement');

  @override
  Widget build(BuildContext context) {
    final isArabic = LocaleScope.of(context).isArabic;
    final p = _project;

    // DATA-HOLDER: Final bilingual page title (EN primary, AR secondary tone: formal engineering).
    final pageTitle = isArabic
        ? 'نظام الحركة — دراسة حالة'
        : 'Movement System — Case Study';

    // DATA-HOLDER: One-line thesis under the title (~120–160 chars per language).
    final subtitle = isArabic
        ? 'منصة تشغيل ميداني تُدار حيث تختفي الشبكة — دون فقدان سلامة البيانات.'
        : 'Field operations where connectivity disappears — without losing data integrity.';

    return CaseStudyLayout(
      title: pageTitle,
      subtitle: subtitle,
      onBackToPortfolio: () => Navigator.of(context).maybePop(),
      leadMedia: ProjectLeadMedia(
        project: p,
        isArabic: isArabic,
        tall: true,
        heroTag: CaseStudyHeroTags.projectLeadImage(p.id),
      ),
      sections: [
        _MovementKpiGrid(isArabic: isArabic),
        _RemoteEnvironmentSection(isArabic: isArabic),
        _LogicalGordianSection(isArabic: isArabic),
        _OfflineFirstEngineSection(isArabic: isArabic),
      ],
    );
  }
}

// —————————————————————————————————————————————————————————————————————
// DATA-HOLDER: KPI labels / helper copy — replace with final marketing strings.
// —————————————————————————————————————————————————————————————————————
class _MovementKpiGrid extends StatelessWidget {
  const _MovementKpiGrid({required this.isArabic});

  final bool isArabic;

  @override
  Widget build(BuildContext context) {
    final items = <_KpiItem>[
      _KpiItem(
        title: isArabic ? 'موثوقية دون اتصال' : 'Offline reliability',
        value: '100%',
        hint: isArabic
            ? 'DATA-HOLDER: أرقام تشغيل فعلية أو مدة التشغيل المتراكمة دون فقدان تقارير.'
            : 'DATA-HOLDER: Paste ops metric (e.g. months without lost reports).',
      ),
      _KpiItem(
        title: isArabic ? 'تعارضات المزامنة' : 'Sync conflicts',
        value: '0',
        hint: isArabic
            ? 'DATA-HOLDER: وصف آلية الكشف/المنع + سياسة دمج التعارضات.'
            : 'DATA-HOLDER: Describe detection/prevention + conflict merge policy.',
      ),
      _KpiItem(
        title: isArabic ? 'توزيع التكلفة' : 'Cost allocation',
        value: isArabic ? 'آلي' : 'Automated',
        hint: isArabic
            ? 'DATA-HOLDER: ربط التكاليف بالمشاريع/الأصول عبر قواعد واضحة.'
            : 'DATA-HOLDER: Tie costs to projects/assets with rule references.',
      ),
    ];

    return LayoutBuilder(
      builder: (context, c) {
        final narrow = c.maxWidth < 720;
        if (narrow) {
          return Column(
            children: [
              for (var i = 0; i < items.length; i++) ...[
                if (i > 0) const SizedBox(height: 12),
                _KpiTile(item: items[i]),
              ],
            ],
          );
        }
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (var i = 0; i < items.length; i++) ...[
              if (i > 0) const SizedBox(width: 14),
              Expanded(child: _KpiTile(item: items[i])),
            ],
          ],
        );
      },
    );
  }
}

class _KpiItem {
  const _KpiItem({
    required this.title,
    required this.value,
    required this.hint,
  });

  final String title;
  final String value;
  final String hint;
}

class _KpiTile extends StatefulWidget {
  const _KpiTile({required this.item});

  final _KpiItem item;

  @override
  State<_KpiTile> createState() => _KpiTileState();
}

class _KpiTileState extends State<_KpiTile> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return AnimatedScale(
      scale: _pressed ? 0.98 : 1,
      duration: const Duration(milliseconds: 120),
      child: Material(
        color: AppColors.surfaceElevated,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTapDown: (_) => setState(() => _pressed = true),
          onTapCancel: () => setState(() => _pressed = false),
          onTapUp: (_) => setState(() => _pressed = false),
          borderRadius: BorderRadius.circular(16),
          onTap: () {
            setState(() => _pressed = false);
            showModalBottomSheet<void>(
              context: context,
              backgroundColor: AppColors.surface,
              showDragHandle: true,
              builder: (ctx) => Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                child: SelectableText(
                  widget.item.hint,
                  style: Theme.of(ctx).textTheme.bodyLarge?.copyWith(
                        color: AppColors.textSecondary,
                        height: 1.45,
                      ),
                ),
              ),
            );
          },
          child: Ink(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
            ),
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.item.value,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w900,
                        color: AppColors.accent,
                      ),
                ),
                const SizedBox(height: 6),
                Text(
                  widget.item.title,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                ),
                const SizedBox(height: 8),
                Text(
                  LocaleScope.of(context).isArabic ? 'اضغط للتفاصيل' : 'Tap for detail',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// DATA-HOLDER: Replace body copy with final EN/AR narrative on offline / remote constraints.
class _RemoteEnvironmentSection extends StatelessWidget {
  const _RemoteEnvironmentSection({required this.isArabic});

  final bool isArabic;

  @override
  Widget build(BuildContext context) {
    final title = isArabic ? 'تحدي البيئة البعيدة' : 'The remote environment challenge';
    final body = isArabic
        ? 'مسارات تشغيل في مناطق بلا إنترنت موثوق — حيث يجب أن تبقى أوامر العمل، حالة الآلة، والتوقيعات الرقمية متسقة حتى عند انقطاع الحلقات الشبكية لأيام.'
        : 'Operations run through offline pockets and unreliable uplinks — work orders, machine state, and attestations must stay coherent when the mesh disappears for hours or days.';

    return _NarrativeSectionCard(
      title: title,
      body: body,
      child: _DisconnectedNodesGraphic(isArabic: isArabic),
    );
  }
}

class _DisconnectedNodesGraphic extends StatelessWidget {
  const _DisconnectedNodesGraphic({required this.isArabic});

  final bool isArabic;

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 16 / 7,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: CustomPaint(
          painter: _DisconnectedNodesPainter(isArabic: isArabic),
        ),
      ),
    );
  }
}

class _DisconnectedNodesPainter extends CustomPainter {
  _DisconnectedNodesPainter({required this.isArabic});

  final bool isArabic;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = AppColors.surface.withValues(alpha: 0.9);
    final r = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, size.width, size.height),
      const Radius.circular(12),
    );
    canvas.drawRRect(r, bg);

    final grid = Paint()
      ..color = AppColors.border.withValues(alpha: 0.35)
      ..strokeWidth = 1;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    void node(Offset c, Color fill, {bool ring = false}) {
      if (ring) {
        canvas.drawCircle(c, 14, Paint()..color = const Color(0xFFEF4444));
        canvas.drawCircle(c, 10, Paint()..color = AppColors.surfaceElevated);
      } else {
        canvas.drawCircle(c, 10, Paint()..color = fill);
      }
    }

    final hq = Offset(size.width * 0.18, size.height * 0.45);
    node(hq, AppColors.accent);

    final n1 = Offset(size.width * 0.42, size.height * 0.28);
    final n2 = Offset(size.width * 0.55, size.height * 0.62);
    final n3 = Offset(size.width * 0.78, size.height * 0.38);
    node(n1, AppColors.textSecondary, ring: true);
    node(n2, AppColors.textSecondary, ring: true);
    node(n3, AppColors.textSecondary, ring: true);

    final solid = Paint()
      ..color = AppColors.accent.withValues(alpha: 0.55)
      ..strokeWidth = 2.2;
    final dashed = Paint()
      ..color = AppColors.textSecondary.withValues(alpha: 0.45)
      ..strokeWidth = 1.6;

    void drawDashed(Offset a, Offset b) {
      const dash = 6.0;
      final d = b - a;
      final len = d.distance;
      final dir = d / len;
      for (double t = 0; t < len; t += dash * 2) {
        final p0 = a + dir * t;
        final p1 = a + dir * (t + dash).clamp(0, len);
        canvas.drawLine(p0, p1, dashed);
      }
    }

    canvas.drawLine(hq, n1, solid);
    drawDashed(n1, n2);
    drawDashed(n2, n3);

    // DATA-HOLDER: Final legend string for the map-style schematic (EN/AR).
    final legend = isArabic
        ? 'عُقد منفصلة · ربط المقر'
        : 'Disconnected nodes · HQ uplink';
    final label = TextPainter(
      text: TextSpan(
        text: legend,
        style: const TextStyle(
          color: AppColors.textSecondary,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
      textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
    )..layout(maxWidth: size.width - 24);
    label.paint(canvas, Offset(14, size.height - label.height - 10));
  }

  @override
  bool shouldRepaint(covariant _DisconnectedNodesPainter oldDelegate) =>
      oldDelegate.isArabic != isArabic;
}

// DATA-HOLDER: Replace process narrative with final EN/AR explanation of cross-project logic + temporary transfer.
class _LogicalGordianSection extends StatelessWidget {
  const _LogicalGordianSection({required this.isArabic});

  final bool isArabic;

  @override
  Widget build(BuildContext context) {
    final title = isArabic ? 'عقدة غورديوس المنطقية' : 'The logical Gordian knot';
    final body = isArabic
        ? 'عندما تنتقل آلة فعليًا بين مشروعين، يجب أن تبقى السجلات متسلسلة: من يملك التكلفة اليوم؟ أين يُحتسب الاستهلاك؟ وكيف نمنع تقارير متعارضة أثناء الحياد المؤقت؟'
        : 'When a machine physically moves between Project A and Project B, ledgers must stay sequenced: who owns cost today, where consumption accrues, and how we prevent conflicting reports during a deliberate temporary transfer window.';

    return _NarrativeSectionCard(
      title: title,
      body: body,
      child: const _CrossProjectFlowDiagram(),
    );
  }
}

class _CrossProjectFlowDiagram extends StatelessWidget {
  const _CrossProjectFlowDiagram();

  @override
  Widget build(BuildContext context) {
    final isArabic = LocaleScope.of(context).isArabic;
    final dir = isArabic ? TextDirection.rtl : TextDirection.ltr;

    Widget box(String label, Color accent) {
      return Expanded(
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: accent.withValues(alpha: 0.55)),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
          ),
        ),
      );
    }

    return Directionality(
      textDirection: dir,
      child: Column(
        children: [
          Row(
            children: [
              box('Project A', const Color(0xFF38BDF8)),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 8),
                child: Icon(Icons.arrow_forward, color: AppColors.textSecondary),
              ),
              Expanded(
                flex: 2,
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 10),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceElevated,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Column(
                    children: [
                      const Icon(Icons.precision_manufacturing, color: AppColors.accent, size: 36),
                      const SizedBox(height: 8),
                      Text(
                        isArabic ? 'نقل مؤقت' : 'Temporary transfer',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.labelLarge?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        isArabic ? 'بوابة سلامة البيانات' : 'Data-integrity gate',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: AppColors.textSecondary,
                            ),
                      ),
                    ],
                  ),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 8),
                child: Icon(Icons.arrow_forward, color: AppColors.textSecondary),
              ),
              box('Project B', const Color(0xFFA78BFA)),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            isArabic
                ? 'DATA-HOLDER: اذكر نقاط التحقق (checksums / version vectors / who signed transfer).'
                : 'DATA-HOLDER: List concrete checkpoints (checksums, version vectors, sign-off roles).',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppColors.textSecondary,
                  height: 1.4,
                ),
          ),
        ],
      ),
    );
  }
}

// DATA-HOLDER: Replace with final EN/AR deep-dive on sync + validation algorithm.
class _OfflineFirstEngineSection extends StatelessWidget {
  const _OfflineFirstEngineSection({required this.isArabic});

  final bool isArabic;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.offline_bolt, color: AppColors.accent),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    isArabic ? 'محرك الأوفلاين أولاً' : 'The offline-first engine',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Text(
              isArabic
                  ? 'تُخزَّن التقارير محليًا مع ختم زمني وسلسلة أحداث للآلة. عند عودة الاتصال، لا يُقبل التقرير إلا إذا تطابق خط زمن الماكينة مع السجل المركزي — ويُرفض أي تعارض قبل دمج التكاليف.'
                  : 'Reports are captured locally with timestamps and a per-machine event chain. On reconnect, a report is accepted only if it extends the machine’s historical timeline against the central ledger — conflicts are rejected before cost allocation runs.',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: AppColors.textSecondary,
                    height: 1.5,
                  ),
            ),
            const SizedBox(height: 16),
            _AlgorithmLadder(isArabic: isArabic),
          ],
        ),
      ),
    );
  }
}

class _AlgorithmLadder extends StatelessWidget {
  const _AlgorithmLadder({required this.isArabic});

  final bool isArabic;

  @override
  Widget build(BuildContext context) {
    final steps = isArabic
        ? [
            '1) التقاط محلي + توقيع الجهاز',
            '2) التحقق من التسلسل مقابل آخر حالة معروفة',
            '3) دمج آمن أو رفض مع سبب قابل للتدقيق',
          ]
        : [
            '1) Local capture + device attestation',
            '2) Sequence check against last known state',
            '3) Safe merge or reject with auditable reason',
          ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (var i = 0; i < steps.length; i++) ...[
          if (i > 0) const SizedBox(height: 10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 8,
                height: 8,
                margin: const EdgeInsets.only(top: 6, right: 10, left: 10),
                decoration: const BoxDecoration(
                  color: AppColors.accent,
                  shape: BoxShape.circle,
                ),
              ),
              Expanded(
                child: Text(
                  steps[i],
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        height: 1.4,
                      ),
                ),
              ),
            ],
          ),
        ],
        const SizedBox(height: 10),
        Text(
          // DATA-HOLDER: Add pseudocode or link to internal doc / diagram asset.
          isArabic
              ? 'DATA-HOLDER: ألصق هنا شيفرة مختصرة أو رابط مخطط الخوارزمية النهائي.'
              : 'DATA-HOLDER: Paste pseudocode snippet or link to final algorithm diagram.',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: AppColors.textSecondary,
                fontStyle: FontStyle.italic,
              ),
        ),
      ],
    );
  }
}

class _NarrativeSectionCard extends StatelessWidget {
  const _NarrativeSectionCard({
    required this.title,
    required this.body,
    required this.child,
  });

  final String title;
  final String body;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
            ),
            const SizedBox(height: 12),
            Text(
              body,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: AppColors.textSecondary,
                    height: 1.5,
                  ),
            ),
            const SizedBox(height: 18),
            child,
          ],
        ),
      ),
    );
  }
}
