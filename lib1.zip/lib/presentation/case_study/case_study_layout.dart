import 'package:flutter/material.dart';

import '../../core/locale/locale_scope.dart';
import '../../core/theme/app_colors.dart';
import '../../domain/localization/app_strings.dart';

/// Shared shell for long-form case studies (Movement, Click, …).
///
/// Pass [leadMedia] as the hero-bearing lead visual; [sections] are stacked
/// body blocks with the same max width as the home page grid.
class CaseStudyLayout extends StatelessWidget {
  const CaseStudyLayout({
    super.key,
    required this.title,
    this.subtitle,
    required this.leadMedia,
    required this.sections,
    required this.onBackToPortfolio,
  });

  final String title;
  final String? subtitle;

  /// Typically includes [Hero] (e.g. [ProjectLeadMedia] with [heroTag]).
  final Widget leadMedia;

  /// Vertical stack of narrative / diagram sections.
  final List<Widget> sections;
  final VoidCallback onBackToPortfolio;

  @override
  Widget build(BuildContext context) {
    final isArabic = LocaleScope.of(context).isArabic;
    final topPad = MediaQuery.paddingOf(context).top;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverPadding(
            padding: EdgeInsets.fromLTRB(16, topPad + 8, 16, 0),
            sliver: SliverToBoxAdapter(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1120),
                  child: _CaseStudyTopBar(
                    isArabic: isArabic,
                    onBack: onBackToPortfolio,
                  ),
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            sliver: SliverToBoxAdapter(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1120),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        title,
                        style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                              fontWeight: FontWeight.w800,
                              height: 1.15,
                            ),
                      ),
                      if (subtitle != null) ...[
                        const SizedBox(height: 10),
                        Text(
                          subtitle!,
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                color: AppColors.textSecondary,
                                height: 1.45,
                              ),
                        ),
                      ],
                      const SizedBox(height: 20),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: AspectRatio(
                          aspectRatio: 16 / 9,
                          child: leadMedia,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            sliver: SliverList.separated(
              itemCount: sections.length,
              separatorBuilder: (context, _) => const SizedBox(height: 28),
              itemBuilder: (context, index) {
                return Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 1120),
                    child: sections[index],
                  ),
                );
              },
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 48)),
        ],
      ),
    );
  }
}

class _CaseStudyTopBar extends StatelessWidget {
  const _CaseStudyTopBar({
    required this.isArabic,
    required this.onBack,
  });

  final bool isArabic;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final scope = LocaleScope.of(context);
    return Row(
      children: [
        OutlinedButton.icon(
          onPressed: onBack,
          icon: Icon(
            isArabic ? Icons.arrow_forward : Icons.arrow_back,
            size: 20,
          ),
          label: Text(
            AppStrings.t(isArabic: isArabic, key: 'case_study_back'),
          ),
        ),
        const Spacer(),
        TextButton.icon(
          onPressed: scope.onToggleLanguage,
          icon: const Icon(Icons.language, size: 20, color: AppColors.accent),
          label: Text(
            AppStrings.t(isArabic: isArabic, key: 'lang_toggle'),
            style: const TextStyle(color: AppColors.textPrimary),
          ),
        ),
      ],
    );
  }
}
