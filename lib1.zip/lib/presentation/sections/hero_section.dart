import 'package:flutter/material.dart';

import '../../core/responsive/breakpoints.dart';
import '../../core/theme/app_colors.dart';
import '../../domain/localization/app_strings.dart';
import '../widgets/content_placeholder.dart';

/// **Content Tip (Hero):** Lead with *outcome* ("systems that last") not title soup.
/// Pair a **single** primary CTA with one secondary (reduces bounce). Headline
/// **42–62 chars EN** keeps one line on common laptop widths.
class HeroSection extends StatefulWidget {
  const HeroSection({
    super.key,
    required this.isArabic,
    required this.onScrollToWork,
  });

  final bool isArabic;
  final VoidCallback onScrollToWork;

  @override
  State<HeroSection> createState() => _HeroSectionState();
}

class _HeroSectionState extends State<HeroSection> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1100),
  );

  @override
  void initState() {
    super.initState();
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Animation<double> _tween(double begin, double end) {
    return CurvedAnimation(
      parent: _controller,
      curve: Interval(begin, end, curve: Curves.easeOutCubic),
    );
  }

  Widget _fadeSlide({
    required double intervalBegin,
    required double intervalEnd,
    required Widget child,
    Offset slideBegin = const Offset(0, 0.045),
  }) {
    final anim = _tween(intervalBegin, intervalEnd);
    return FadeTransition(
      opacity: anim,
      child: SlideTransition(
        position: Tween<Offset>(begin: slideBegin, end: Offset.zero).animate(anim),
        child: child,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isArabic = widget.isArabic;
    final w = MediaQuery.sizeOf(context).width;
    final pad = w >= AppBreakpoints.desktop ? 64.0 : 24.0;
    final headline = Theme.of(context).textTheme.displaySmall?.copyWith(
          fontWeight: FontWeight.w700,
          height: 1.08,
          letterSpacing: isArabic ? 0 : -0.6,
        );

    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF070B10),
            Color(0xFF0B1220),
            Color(0xFF0E1A2A),
          ],
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            right: isArabic ? null : -80,
            left: isArabic ? -80 : null,
            top: -40,
            child: _GlowBlob(color: AppColors.accent.withValues(alpha: 0.22)),
          ),
          Positioned(
            left: isArabic ? null : -120,
            right: isArabic ? -120 : null,
            bottom: -80,
            child: _GlowBlob(color: AppColors.accentDim.withValues(alpha: 0.18)),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(pad, 48, pad, 72),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1120),
                child: LayoutBuilder(
                  builder: (context, c) {
                    final stackVertical = c.maxWidth < 860;
                    final content = Column(
                      crossAxisAlignment: stackVertical
                          ? CrossAxisAlignment.center
                          : (isArabic ? CrossAxisAlignment.end : CrossAxisAlignment.start),
                      children: [
                        _fadeSlide(
                          intervalBegin: 0.0,
                          intervalEnd: 0.32,
                          slideBegin: const Offset(0, -0.04),
                          child: Text(
                            AppStrings.t(isArabic: isArabic, key: 'hero_kicker'),
                            textAlign: stackVertical ? TextAlign.center : (isArabic ? TextAlign.right : TextAlign.left),
                            style: Theme.of(context).textTheme.labelLarge?.copyWith(
                                  color: AppColors.accent,
                                  letterSpacing: 1.2,
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        _fadeSlide(
                          intervalBegin: 0.08,
                          intervalEnd: 0.45,
                          child: Text(
                            AppStrings.t(isArabic: isArabic, key: 'hero_headline'),
                            textAlign: stackVertical ? TextAlign.center : (isArabic ? TextAlign.right : TextAlign.left),
                            style: headline,
                          ),
                        ),
                        const SizedBox(height: 18),
                        _fadeSlide(
                          intervalBegin: 0.14,
                          intervalEnd: 0.55,
                          child: Text(
                            AppStrings.t(isArabic: isArabic, key: 'hero_sub'),
                            textAlign: stackVertical ? TextAlign.center : (isArabic ? TextAlign.right : TextAlign.left),
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  color: AppColors.textSecondary,
                                  height: 1.45,
                                  fontWeight: FontWeight.w400,
                                ),
                          ),
                        ),
                        const SizedBox(height: 32),
                        _fadeSlide(
                          intervalBegin: 0.22,
                          intervalEnd: 0.68,
                          child: Wrap(
                            spacing: 12,
                            runSpacing: 12,
                            textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
                            alignment: stackVertical
                                ? WrapAlignment.center
                                : (isArabic ? WrapAlignment.end : WrapAlignment.start),
                            children: [
                              ElevatedButton(
                                onPressed: () {/* TODO: mailto: or Calendly URL */},
                                child: Text(AppStrings.t(isArabic: isArabic, key: 'hero_cta_primary')),
                              ),
                              OutlinedButton(
                                onPressed: widget.onScrollToWork,
                                child: Text(AppStrings.t(isArabic: isArabic, key: 'hero_cta_secondary')),
                              ),
                            ],
                          ),
                        ),
                      ],
                    );

                    final avatar = _fadeSlide(
                      intervalBegin: 0.0,
                      intervalEnd: 0.4,
                      slideBegin: const Offset(0, 0.06),
                      child: _AvatarBlock(isArabic: isArabic),
                    );

                    if (stackVertical) {
                      return Column(
                        children: [
                          avatar,
                          const SizedBox(height: 28),
                          content,
                        ],
                      );
                    }

                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        if (!isArabic) ...[
                          Expanded(flex: 5, child: avatar),
                          const SizedBox(width: 36),
                        ],
                        Expanded(flex: 7, child: content),
                        if (isArabic) ...[
                          const SizedBox(width: 36),
                          Expanded(flex: 5, child: avatar),
                        ],
                      ],
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AvatarBlock extends StatelessWidget {
  const _AvatarBlock({required this.isArabic});

  final bool isArabic;

  @override
  Widget build(BuildContext context) {
    // TODO: Replace with `assets/images/yahya_profile.jpg` (1:1, 800–1200px).
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: SizedBox(
            width: 220,
            height: 220,
            child: Image.asset(
              'assets/images/yahya_profile.jpg',
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => ContentPlaceholder(
                label: isArabic
                    ? 'TODO: صورة شخصية احترافية مربعة 1:1 لبناء الثقة'
                    : 'TODO: 1:1 professional headshot (trust + enterprise tone)',
                aspectRatio: 1,
                icon: Icons.person_outline,
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        Text(
          AppStrings.t(isArabic: isArabic, key: 'brand_name'),
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
        ),
      ],
    );
  }
}

class _GlowBlob extends StatelessWidget {
  const _GlowBlob({required this.color});

  final Color color;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: 280,
        height: 280,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
        ),
      ),
    );
  }
}
